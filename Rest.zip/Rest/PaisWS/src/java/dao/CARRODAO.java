/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ws.modelo.CARROModelo;

/**
 *
 * @author tadeu
 */
public class CARRODAO {
    
    public CARRODAO()
    {
        
    }
    
    public boolean inserir(CARROModelo CARRO)
    {
        String sql = "INSERT INTO CARRO(CARRO,capital,continente,populacao,sigla) VALUES(?,?,?,?,?)";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        //PreparedStatement pst = dao.Conexao.getPreparedStatement(sql);
        try {
            
            pst.setString(1, CARRO.getModeloCARRO());
            pst.setString(2, CARRO.getMarcaCARRO());
            pst.setString(3, CARRO.getAnoCARRO());
            pst.setString(4, CARRO.getCategoriaCARRO());
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public boolean atualizar(CARROModelo CARRO)
    {
        String sql = "UPDATE CARRO set CARRO=?, capital=?, continente=?, populacao=?, sigla=? where id=?";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
            pst.setInt(6, CARRO.getIdCARRO());
            pst.setString(1, CARRO.getModeloCARRO());
            pst.setString(2, CARRO.getMarcaCARRO());
            pst.setString(3, CARRO.getAnoCARRO());
            pst.setString(4, CARRO.getCategoriaCARRO());
  
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public Boolean excluir(CARROModelo CARRO)
    {
        String sql = "DELETE FROM CARRO where id= ?";
        Boolean retorno = false;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
          
            pst.setInt(1, CARRO.getIdCARRO());
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
         } catch (SQLException ex) {
            Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
            
            retorno = false;
        }
        return retorno;
    }
    
    public List<CARROModelo> listar()
    {
        String sql = "SELECT * FROM CARRO";
        List<CARROModelo> lista = new ArrayList<CARROModelo>();
        CARROModelo CARRO = null;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            ResultSet res = pst.executeQuery();
            while(res.next()){
            
                CARRO = new CARROModelo();
                CARRO.setIdCARRO(res.getInt("id"));
                CARRO.setModeloCARRO(res.getString("Modelo"));
                CARRO.setMarcaCARRO(res.getString("Marca"));
                CARRO.setAnoCARRO(res.getString("Ano"));
                CARRO.setCategoriaCARRO(res.getString("Categoria"));
                lista.add(CARRO);
            }
               
        } catch (SQLException ex) {
            Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
            CARRO = new CARROModelo();
            CARRO.setModeloCARRO(ex.getMessage().toString());
            lista.add(CARRO);
        }
        
        return lista;
        
    }
    
    public CARROModelo buscar(CARROModelo CARRO)
    {
        String sql = "SELECT * FROM CARRO where CARRO=?";
        CARROModelo retorno = new CARROModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, CARRO.getModeloCARRO());
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new CARROModelo();
                retorno.setIdCARRO(res.getInt("id"));
                retorno.setModeloCARRO(res.getString("CARRO"));
                retorno.setMarcaCARRO(res.getString("capital"));
                retorno.setAnoCARRO(res.getString("continente"));
                retorno.setCategoriaCARRO(res.getString("populacao"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        modelo.setModeloCARRO(nmCARRO);
        CARRO.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
    
    public CARROModelo buscarPorSigla(CARROModelo CARRO)
    {
        String sql = "select * from CARRO where sigla like ?";
        CARROModelo retorno = new CARROModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new CARROModelo();
                retorno.setIdCARRO(res.getInt("id"));
                retorno.setModeloCARRO(res.getString("CARRO"));
                retorno.setMarcaCARRO(res.getString("capital"));
                retorno.setAnoCARRO(res.getString("continente"));
                retorno.setCategoriaCARRO(res.getString("populacao"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        modelo.setModeloCARRO(nmCARRO);
        CARRO.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
}
