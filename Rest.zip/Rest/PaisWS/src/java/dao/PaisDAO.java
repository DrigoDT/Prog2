/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ws.modelo.PaisModelo;

/**
 *
 * @author tadeu
 */
public class PaisDAO {
    
    public PaisDAO()
    {
        
    }
    
    public boolean inserir(PaisModelo Pais)
    {
        String sql = "INSERT INTO pais(pais,capital,continente,populacao,sigla) VALUES(?,?,?,?,?)";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        //PreparedStatement pst = dao.Conexao.getPreparedStatement(sql);
        try {
            
            pst.setString(1, Pais.getNomePais());
            pst.setString(2, Pais.getCapitalPais());
            pst.setString(3, Pais.getContinentePais());
            pst.setFloat(4, Pais.getPopulacaoPais());
            pst.setString(5, Pais.getSiglaPais());
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public boolean atualizar(PaisModelo Pais)
    {
        String sql = "UPDATE pais set pais=?, capital=?, continente=?, populacao=?, sigla=? where id=?";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
            pst.setInt(6, Pais.getIdPais());
            pst.setString(1, Pais.getNomePais());
            pst.setString(2, Pais.getCapitalPais());
            pst.setString(3, Pais.getContinentePais());
            pst.setFloat(4, Pais.getPopulacaoPais());
            pst.setString(5, Pais.getSiglaPais());
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public Boolean excluir(PaisModelo Pais)
    {
        String sql = "DELETE FROM pais where id= ?";
        Boolean retorno = false;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
          
            pst.setInt(1, Pais.getIdPais());
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
         } catch (SQLException ex) {
            Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            retorno = false;
        }
        return retorno;
    }
    
    public List<PaisModelo> listar()
    {
        String sql = "SELECT * FROM pais";
        List<PaisModelo> lista = new ArrayList<PaisModelo>();
        PaisModelo pais = null;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            ResultSet res = pst.executeQuery();
            while(res.next()){
            
                pais = new PaisModelo();
                pais.setIdPais(res.getInt("id"));
                pais.setNomePais(res.getString("pais"));
                pais.setCapitalPais(res.getString("capital"));
                pais.setContinentePais(res.getString("continente"));
                pais.setPopulacaoPais(res.getFloat("populacao"));
                pais.setSiglaPais(res.getString("sigla"));
                lista.add(pais);
            }
               
        } catch (SQLException ex) {
            Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
            pais = new PaisModelo();
            pais.setNomePais(ex.getMessage().toString());
            lista.add(pais);
        }
        
        return lista;
        
    }
    
    public PaisModelo buscar(PaisModelo Pais)
    {
        String sql = "SELECT * FROM pais where pais=?";
        PaisModelo retorno = new PaisModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, Pais.getNomePais());
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new PaisModelo();
                retorno.setIdPais(res.getInt("id"));
                retorno.setNomePais(res.getString("pais"));
                retorno.setCapitalPais(res.getString("capital"));
                retorno.setContinentePais(res.getString("continente"));
                retorno.setPopulacaoPais(res.getFloat("populacao"));
                retorno.setSiglaPais(res.getString("sigla"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*PaisDAO pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        modelo.setNomePais(nmPais);
        pais.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
    
    public PaisModelo buscarPorSigla(PaisModelo Pais)
    {
        String sql = "select * from pais where sigla like ?";
        PaisModelo retorno = new PaisModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, "%" + Pais.getSiglaPais() + "%");
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new PaisModelo();
                retorno.setIdPais(res.getInt("id"));
                retorno.setNomePais(res.getString("pais"));
                retorno.setCapitalPais(res.getString("capital"));
                retorno.setContinentePais(res.getString("continente"));
                retorno.setPopulacaoPais(res.getFloat("populacao"));
                retorno.setSiglaPais(res.getString("sigla"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*PaisDAO pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        modelo.setNomePais(nmPais);
        pais.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
}
