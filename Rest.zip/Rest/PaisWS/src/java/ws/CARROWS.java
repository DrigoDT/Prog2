/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import com.google.gson.Gson;
import dao.Conexao;

import dao.CARRODAO;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import ws.modelo.CARROModelo;



/**
 * REST Web Service
 *
 * @author tadeu
 */
@Path("CARROws")
public class CARROWS {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of CARROWS
     */
    public CARROWS() 
    {
        
    }
   
    /**
     * Retrieves representation of an instance of ws.CARROWS
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("application/text")
    @Path("Teste/get")
    public String getJson() 
    {
        //TODO return proper representation object
       return "Teste RESTFULL JAVA";
    }
    
    @GET
    @Produces("application/json")
    @Path("CARRO/get/{CARRO}")
    public String getCARRO(@PathParam("CARRO")String nmCARRO)
    {
        CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        Gson g = new Gson();
        
        modelo.setModeloCARRO(nmCARRO);
        CARROModelo retorno  = CARRO.buscar(modelo);
        
        return g.toJson(retorno);
    }
    
    @GET
    @Produces("application/json")
    public String getCARROSigla(@PathParam("CARRO")String nmCARRO)
    {
        CARROModelo CARRO = new CARROModelo();
        String sql = "SELECT * FROM CARRO where sigla like ?";
        CARROModelo retorno = new CARROModelo();
        Gson g = new Gson();
        
        nmCARRO = nmCARRO.toUpperCase();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, "%" + nmCARRO + "%");
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new CARROModelo();
                retorno.setIdCARRO(res.getInt("id"));
                retorno.setModeloCARRO(res.getString("CARRO"));
                retorno.setMarcaCARRO(res.getString("capital"));
                retorno.setAnoCARRO(res.getString("continente"));
                retorno.setCategoriaCARRO(res.getString("populacao"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.CARRODAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return g.toJson(retorno);
        
    }
    
    @GET
    @Produces("application/json")
    @Path("CARRO/list")
    public String listaCARRO()
    {
        String sql = "select * from db_CARRO.dbo.dbCARRO";
        List<CARROModelo> lista = new ArrayList<CARROModelo>();
        CARRODAO CARRO = new CARRODAO();
        lista = CARRO.listar();
        Gson g = new Gson();
        return g.toJson(lista);
    }
    
    @DELETE
    @Produces("application/json")
    @Path("excluirCARRO/{id}")
    public String excluirCARRO(@PathParam("id")int idCARRO)
    {
        CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        modelo.setIdCARRO(idCARRO);
        Gson g = new Gson();
        Boolean retorno = CARRO.excluir(modelo);
        return g.toJson(retorno);
    }
    
    @POST
    @Produces("application/json")
    @Path("inserirCARRO/{nome}/{continente}/{capital}/{populacao}/{sigla}")
    public String inserirCARRO(@PathParam("nome")String nome, @PathParam("continente")String continente, 
                              @PathParam("capital")String capital, @PathParam("populacao") float populacao,@PathParam("sigla") String sigla)
    {
        CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        modelo.setModeloCARRO(nome);
        modelo.setAnoCARRO(continente);
        modelo.setMarcaCARRO(capital);

        Gson g = new Gson();
        Boolean retorno = false;
        retorno = CARRO.inserir(modelo);
        return g.toJson(retorno);
    }
        
    @POST
    @Produces("application/json")
    @Path("atualizarCARRO/{nome}/{continente}/{capital}/{populacao}/{sigla}/{id}")
    public String atualizarCARRO(@PathParam("nome")String nome, 
                                @PathParam("continente")String continente, 
                                @PathParam("capital")String capital, 
                                @PathParam("populacao") String populacao, 
                                @PathParam("sigla") String sigla, 
                                @PathParam("id") int id)
    {
        CARRODAO CARRO = new CARRODAO();
        CARROModelo modelo = new CARROModelo();
        modelo.setModeloCARRO(nome);
        modelo.setAnoCARRO(continente);
        modelo.setMarcaCARRO(capital);
        modelo.setIdCARRO(id);
        Gson g = new Gson();
        Boolean retorno = false;
        retorno = CARRO.atualizar(modelo);
        return g.toJson(retorno);
        
        
    }

    /**
     * PUT method for updating or creating an instance of CARROWS
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Consumes("application/json")
    public void putJson(String content) 
    {
    }
}
