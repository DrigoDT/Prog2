/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.modelo;

/**
 *
 * @author tadeu
 */
public class PaisModelo {
    
    private int idPais;
    private String NomePais;
    private float PopulacaoPais;
    private String ContinentePais;
    private String SiglaPais;
    private String CapitalPais;

    /**
     * @return the NomePais
     */
    public String getNomePais() {
        return NomePais;
    }

    /**
     * @param NomePais the NomePais to set
     */
    public void setNomePais(String NomePais) {
        this.NomePais = NomePais;
    }

    /**
     * @return the PopulacaoPais
     */
    public float getPopulacaoPais() {
        return PopulacaoPais;
    }

    /**
     * @param PopulacaoPais the PopulacaoPais to set
     */
    public void setPopulacaoPais(float PopulacaoPais) {
        this.PopulacaoPais = PopulacaoPais;
    }

    /**
     * @return the ContinentePais
     */
    public String getContinentePais() {
        return ContinentePais;
    }

    /**
     * @param ContinentePais the ContinentePais to set
     */
    public void setContinentePais(String ContinentePais) {
        this.ContinentePais = ContinentePais;
    }

    public void Set(String brasil) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the idPais
     */
    public int getIdPais() {
        return idPais;
    }

    /**
     * @param idPais the idPais to set
     */
    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    /**
     * @return the SiglaPais
     */
    public String getSiglaPais() {
        return SiglaPais;
    }

    /**
     * @param SiglaPais the SiglaPais to set
     */
    public void setSiglaPais(String SiglaPais) {
        this.SiglaPais = SiglaPais;
    }

    /**
     * @return the CapitalPais
     */
    public String getCapitalPais() {
        return CapitalPais;
    }

    /**
     * @param CapitalPais the CapitalPais to set
     */
    public void setCapitalPais(String CapitalPais) {
        this.CapitalPais = CapitalPais;
    }
    
    
}
