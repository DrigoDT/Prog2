package br.com.ProjetoPaises.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.Scanner;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/")
public class PaisController {
	
	@CrossOrigin(origins="*")
	@RequestMapping(value="/inicial")
	public ModelAndView userPage(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttrs, HttpSession session) throws SQLException, ClassNotFoundException {
				
		return new ModelAndView("inicial");
	}
	
	@CrossOrigin(origins="*")
	@RequestMapping(value="/mapa", method=RequestMethod.GET)
	public ModelAndView MapaMundi(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttrs, HttpSession session) throws SQLException, ClassNotFoundException, IOException {
		
		return new ModelAndView("mapa");
	}
	
	@RequestMapping(value = "getSigla", method = RequestMethod.POST)
	public ModelAndView mapa(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttrs, HttpSession session) throws SQLException, ClassNotFoundException, IOException {
		
		return new ModelAndView("mapa");
	}
}
