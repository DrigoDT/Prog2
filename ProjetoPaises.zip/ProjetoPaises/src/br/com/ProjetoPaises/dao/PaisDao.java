package br.com.ProjetoPaises.dao;

public class PaisDao {

}
