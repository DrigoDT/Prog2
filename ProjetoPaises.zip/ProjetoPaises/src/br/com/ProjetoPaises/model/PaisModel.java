package br.com.ProjetoPaises.model;

public class PaisModel {

}
