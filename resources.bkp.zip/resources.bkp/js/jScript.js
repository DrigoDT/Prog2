/**
 * 
 */
function GridPaises()
{	
	$("#jqGrid").jqGrid({
		url: 'http://192.168.0.10:8080/PaisWS/webresources/paisws/Pais/list',
		datatype: "json",
		 colModel: [
			{ label: 'id', name: 'idPais', width: -1}, 
			{ label: 'Sigla', name: 'sigla', width: -1},
			{ label: 'Nome', name: 'NomePais', width: 75 },
			{ label: 'Capital', name:'CapitalPais', width: 75},
			{ label: 'Continente', name: 'ContinentePais', width: 90 },
			{ label: 'Populacao', name: 'PopulacaoPais', width: 100 },
		],
		viewrecords: true, // show the current page, data rang and total records on the toolbar
		width: 900,
		height: 600,
		rowNum: 50,
		loadonce: true, // this is just for the demo
		pager: "#jqGridPager",
		onSelectRow: function(id){ 
			replaceValues(id);
		},
	});
}

function replaceValues(id) 
{
	var grid = $("#jqGrid");
	var nm =  grid.jqGrid('getCell', id, 'NomePais');
	var ct =  grid.jqGrid('getCell', id, 'ContinentePais');
	var pop =  grid.jqGrid('getCell', id, 'PopulacaoPais');
	var cap = grid.jqGrid('getCell', id, 'CapitalPais')
	//document.getElementById("txtPais").innerHTML = nm;
	//document.getElementById("txtCont").innerHTML = ct;
	//document.getElementById("populacao").innerHTML = pop;
	//document.getElementById("capital").innerHTML = cap;
	$('#txtPais').val(nm);
	$('#txtCont').val(ct);
	$('#txtPop').val(pop);
	$('#txtCap').val(cap);
}


function selectRow() 
{
	jQuery('#jqGrid').jqGrid('setSelection','1014');
}

