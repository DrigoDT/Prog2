/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**CRIAR TABELA

 * Author:  rodrigodelbone
 * Created: May 23, 2019
 */
FCREATE TABLE jogo (
id INT NOT NULL, 
timeA VARCHAR (255) NOT NULL,
timeB VARCHAR (255) NOT NULL,
golsA INT NOT NULL,
golsB INT NOT NULL,
PRIMARY KEY(id)
);
SELECT * FROM jogo

