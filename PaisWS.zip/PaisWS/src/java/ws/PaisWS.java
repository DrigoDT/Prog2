/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import com.google.gson.Gson;
import dao.Conexao;

import dao.PaisDAO;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import ws.modelo.PaisModelo;



/**
 * REST Web Service
 *
 * @author tadeu
 */
@Path("paisws")
public class PaisWS {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of PaisWS
     */
    public PaisWS() 
    {
        
    }
   
    /**
     * Retrieves representation of an instance of ws.PaisWS
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("application/text")
    @Path("Teste/get")
    public String getJson() 
    {
        //TODO return proper representation object
       return "Teste RESTFULL JAVA";
    }
    
    @GET
    @Produces("application/json")
    @Path("Pais/get/{pais}")
    public String getPais(@PathParam("pais")String nmPais)
    {
        PaisDAO Pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        Gson g = new Gson();
        
        modelo.setNomePais(nmPais);
        PaisModelo retorno  = Pais.buscar(modelo);
        
        return g.toJson(retorno);
    }
    
    @GET
    @Produces("application/json")
    @Path("PaisSigla/get/{pais}")
    public String getPaisSigla(@PathParam("pais")String nmPais)
    {
        PaisModelo Pais = new PaisModelo();
        String sql = "SELECT * FROM pais where sigla like ?";
        PaisModelo retorno = new PaisModelo();
        Gson g = new Gson();
        
        nmPais = nmPais.toUpperCase();
        
        Pais.setSiglaPais(nmPais);
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, "%" + nmPais + "%");
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new PaisModelo();
                retorno.setIdPais(res.getInt("id"));
                retorno.setNomePais(res.getString("pais"));
                retorno.setCapitalPais(res.getString("capital"));
                retorno.setContinentePais(res.getString("continente"));
                retorno.setPopulacaoPais(res.getFloat("populacao"));
                retorno.setSiglaPais(res.getString("continente"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.PaisDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return g.toJson(retorno);
        
    }
    
    @GET
    @Produces("application/json")
    @Path("Pais/list")
    public String listaPais()
    {
        String sql = "select * from db_pais.dbo.dbPais";
        List<PaisModelo> lista = new ArrayList<PaisModelo>();
        PaisDAO pais = new PaisDAO();
        lista = pais.listar();
        Gson g = new Gson();
        return g.toJson(lista);
    }
    
    @DELETE
    @Produces("application/json")
    @Path("excluirpais/{id}")
    public String excluirPais(@PathParam("id")int idPais)
    {
        PaisDAO pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        modelo.setIdPais(idPais);
        Gson g = new Gson();
        Boolean retorno = pais.excluir(modelo);
        return g.toJson(retorno);
    }
    
    @POST
    @Produces("application/json")
    @Path("inserirPais/{nome}/{continente}/{capital}/{populacao}/{sigla}")
    public String inserirPais(@PathParam("nome")String nome, @PathParam("continente")String continente, 
                              @PathParam("capital")String capital, @PathParam("populacao") float populacao,@PathParam("sigla") String sigla)
    {
        PaisDAO pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        modelo.setNomePais(nome);
        modelo.setContinentePais(continente);
        modelo.setCapitalPais(capital);
        modelo.setPopulacaoPais(populacao);
        modelo.setSiglaPais(sigla);
        Gson g = new Gson();
        Boolean retorno = false;
        retorno = pais.inserir(modelo);
        return g.toJson(retorno);
    }
        
    @POST
    @Produces("application/json")
    @Path("atualizarPais/{nome}/{continente}/{capital}/{populacao}/{sigla}/{id}")
    public String atualizarPais(@PathParam("nome")String nome, 
                                @PathParam("continente")String continente, 
                                @PathParam("capital")String capital, 
                                @PathParam("populacao") String populacao, 
                                @PathParam("sigla") String sigla, 
                                @PathParam("id") int id)
    {
        PaisDAO pais = new PaisDAO();
        PaisModelo modelo = new PaisModelo();
        modelo.setNomePais(nome);
        modelo.setContinentePais(continente);
        modelo.setCapitalPais(capital);
        modelo.setPopulacaoPais(Float.parseFloat(populacao));
        modelo.setSiglaPais(sigla);
        modelo.setIdPais(id);
        Gson g = new Gson();
        Boolean retorno = false;
        retorno = pais.atualizar(modelo);
        return g.toJson(retorno);
        
        
    }

    /**
     * PUT method for updating or creating an instance of PaisWS
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Consumes("application/json")
    public void putJson(String content) 
    {
    }
}
