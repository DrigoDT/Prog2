/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import com.google.gson.Gson;
import dao.Conexao;

import dao.JOGODAO;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import ws.TIMEA.JOGOTIMEA;



/**
 * REST Web Service
 *
 * @author tadeu
 */
@Path("JOGOws")
public class JOGOWS {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of JOGOWS
     */
    public JOGOWS() 
    {
        
    }
   
    /**
     * Retrieves representation of an instance of ws.JOGOWS
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("application/text")
    @Path("Teste/get")
    public String getJson() 
    {
        //TODO return proper representation object
       return "Teste RESTFULL JAVA";
    }
    
    @GET
    @Produces("application/json")
    @Path("JOGO/get/{JOGO}")
    public String getJOGO(@PathParam("JOGO")String nmJOGO)
    {
        JOGODAO JOGO = new JOGODAO();
        JOGOTIMEA TIMEA = new JOGOTIMEA();
        Gson g = new Gson();
        
        TIMEA.setTIMEAJOGO(nmJOGO);
        JOGOTIMEA retorno  = JOGO.buscar(TIMEA);
        
        return g.toJson(retorno);
    }
    
    @GET
    @Produces("application/json")
    public String getJOGOSigla(@PathParam("JOGO")String nmJOGO)
    {
        JOGOTIMEA JOGO = new JOGOTIMEA();
        String sql = "SELECT * FROM JOGO where sigla like ?";
        JOGOTIMEA retorno = new JOGOTIMEA();
        Gson g = new Gson();
        
        nmJOGO = nmJOGO.toUpperCase();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, "%" + nmJOGO + "%");
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new JOGOTIMEA();
                retorno.setIdJOGO(res.getInt("id"));
                retorno.setTIMEAJOGO(res.getString("JOGO"));
                retorno.setMarcaJOGO(res.getString("TIMEB"));
                retorno.setTIMEBJOGO(res.getString("GOLSA"));
                retorno.setCategoriaJOGO(res.getString("GOLSB"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.JOGODAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return g.toJson(retorno);
        
    }
    
    @GET
    @Produces("application/json")
    @Path("JOGO/list")
    public String listaJOGO()
    {
        String sql = "select * from db_JOGO.dbo.dbJOGO";
        List<JOGOTIMEA> lista = new ArrayList<JOGOTIMEA>();
        JOGODAO JOGO = new JOGODAO();
        lista = JOGO.listar();
        Gson g = new Gson();
        return g.toJson(lista);
    }
    
    @DELETE
    @Produces("application/json")
    @Path("excluirJOGO/{id}")
    public String excluirJOGO(@PathParam("id")int idJOGO)
    {
        JOGODAO JOGO = new JOGODAO();
        JOGOTIMEA TIMEA = new JOGOTIMEA();
        TIMEA.setIdJOGO(idJOGO);
        Gson g = new Gson();
        Boolean retorno = JOGO.excluir(TIMEA);
        return g.toJson(retorno);
    }
    
    @POST
    @Produces("application/json")
    @Path("inserirJOGO/{TIMEA}/{GOLSA}/{TIMEB}/{GOLSB}/{sigla}")
    public String inserirJOGO(@PathParam("TIMEA")String TIMEA, @PathParam("GOLSA")String GOLSA, 
                              @PathParam("TIMEB")String TIMEB, @PathParam("GOLSB") float GOLSB,@PathParam("sigla") String sigla)
    {
        JOGODAO JOGO = new JOGODAO();
        JOGOTIMEA TIMEA = new JOGOTIMEA();
        TIMEA.setTIMEAJOGO(TIMEA);
        TIMEA.setTIMEBJOGO(GOLSA);
        TIMEA.setMarcaJOGO(TIMEB);

        Gson g = new Gson();
        Boolean retorno = false;
        retorno = JOGO.inserir(TIMEA);
        return g.toJson(retorno);
    }
        
    @POST
    @Produces("application/json")
    @Path("atualizarJOGO/{TIMEA}/{GOLSA}/{TIMEB}/{GOLSB}/{sigla}/{id}")
    public String atualizarJOGO(@PathParam("TIMEA")String TIMEA, 
                                @PathParam("GOLSA")String GOLSA, 
                                @PathParam("TIMEB")String TIMEB, 
                                @PathParam("GOLSB") String GOLSB, 
                                @PathParam("sigla") String sigla, 
                                @PathParam("id") int id)
    {
        JOGODAO JOGO = new JOGODAO();
        JOGOTIMEA TIMEA = new JOGOTIMEA();
        TIMEA.setTIMEAJOGO(TIMEA);
        TIMEA.setTIMEBJOGO(GOLSA);
        TIMEA.setMarcaJOGO(TIMEB);
        TIMEA.setIdJOGO(id);
        Gson g = new Gson();
        Boolean retorno = false;
        retorno = JOGO.atualizar(TIMEA);
        return g.toJson(retorno);
        
        
    }

    /**
     * PUT method for updating or creating an instance of JOGOWS
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Consumes("application/json")
    public void putJson(String content) 
    {
    }
}
