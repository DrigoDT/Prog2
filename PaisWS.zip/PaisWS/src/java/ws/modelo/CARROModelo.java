/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.modelo;

/**
 *
 * @author tadeu
 */
public class CARROModelo {
    
    private int idCARRO;
    private String ModeloCARRO;
    private String MarcaCARRO;
    private String AnoCARRO;
    private String CategoriaCARRO;

    /**
     * @return the ModeloCARRO
     */
    public String getModeloCARRO() {
        return ModeloCARRO;
    }

    /**
     * @param ModeloCARRO the ModeloCARRO to set
     */
    public void setModeloCARRO(String ModeloCARRO) {
        this.ModeloCARRO = ModeloCARRO;
    }

   
    /**
     * @return the MarcaCARRO
     */
    public String getMarcaCARRO() {
        return MarcaCARRO;
    }

    /**
     * @param MarcaCARRO the MarcaCARRO to set
     */
    public void setMarcaCARRO(String MarcaCARRO) {
        this.MarcaCARRO = MarcaCARRO;
    }

    public void Set(String brasil) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the idCARRO
     */
    public int getIdCARRO() {
        return idCARRO;
    }

    /**
     * @param idCARRO the idCARRO to set
     */
    public void setIdCARRO(int idCARRO) {
        this.idCARRO = idCARRO;
    }

    /**
     * @return the CategoriaCARRO
     */
    public String getCategoriaCARRO() {
        return CategoriaCARRO;
    }

    /**
     * @param CategoriaCARRO the CategoriaCARRO to set
     */
    public void setCategoriaCARRO(String CategoriaCARRO) {
        this.CategoriaCARRO = CategoriaCARRO;
    }

    /**
     * @return the AnoCARRO
     */
    public String getAnoCARRO() {
        return AnoCARRO;
    }

    /**
     * @param AnoCARRO the AnoCARRO to set
     */
    public void setAnoCARRO(String AnoCARRO) {
        this.AnoCARRO = AnoCARRO;
    }
    
    
}
