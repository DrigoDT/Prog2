/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.modelo;

/**
 *
 * @author tadeu
 */
public class JOGOModelo {
    
    private int idJOGO;
    private String NomePais;
    private float PopulacaoPais;
    private String ContinentePais;
    private String SiglaPais;
    private String TIMEAJOGO;

    /**
     * @return the NomePais
     */
    public String getNomePais() {
        return NomePais;
    }

    /**
     * @param NomePais the NomePais to set
     */
    public void setNomePais(String NomePais) {
        this.NomePais = NomePais;
    }

    /**
     * @return the PopulacaoPais
     */
    public float getPopulacaoPais() {
        return PopulacaoPais;
    }

    /**
     * @param PopulacaoPais the PopulacaoPais to set
     */
    public void setPopulacaoPais(float PopulacaoPais) {
        this.PopulacaoPais = PopulacaoPais;
    }

    /**
     * @return the ContinentePais
     */
    public String getContinentePais() {
        return ContinentePais;
    }

    /**
     * @param ContinentePais the ContinentePais to set
     */
    public void setContinentePais(String ContinentePais) {
        this.ContinentePais = ContinentePais;
    }

    public void Set(String brasil) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the idJOGO
     */
    public int getIdJOGO() {
        return idJOGO;
    }

    /**
     * @param idJOGO the idJOGO to set
     */
    public void setIdJOGO(int idJOGO) {
        this.idJOGO = idJOGO;
    }
    /**
     * @return the TIMEAJOGO
     */
    public String getTIMEAJOGO() {
        return TIMEAJOGO;
    }

    /**
     * @param TIMEAJOGO the TIMEAJOGO to set
     */
    public void setTIMEAJOGO(String TIMEAJOGO) {
        this.TIMEAJOGO = TIMEAJOGO;
    }
    
    
}

