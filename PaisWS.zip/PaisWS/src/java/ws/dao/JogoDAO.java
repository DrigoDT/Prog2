/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ws.modelo.JOGOModelo;

/**
 *
 * @author tadeu
 */
public class JogoDAO {
    
    public JogoDAO()
    {
        
    }
    
    public boolean inserir(JOGOModelo JOGO)
    {
        String sql = "INSERT INTO TIMEA(TIMEA,TIMEB,GOLSA,GOLSB,sigla) VALUES(?,?,?,?,?)";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        //PreparedStatement pst = dao.Conexao.getPreparedStatement(sql);
        try {
            
            pst.setString(1, JOGO.getTIMEAJOGO());
            pst.setString(2, JOGO.getTIMEBJOGO());
            pst.setString(3, JOGO.getGOLSAJOGO());
            pst.setFloat(4, JOGO.getGOLSBJOGO());
            pst.setString(5, JOGO.getSiglaJOGO());
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public boolean atualizar(JOGOModelo JOGO)
    {
        String sql = "UPDATE TIMEA set TIMEA=?, TIMEB=?, GOLSA=?, GOLSB=?, where id=?";
        Boolean retorno = false;
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
            pst.setInt(6, JOGO.getIdJOGO());
            pst.setString(1, JOGO.getTIMEAJOGO());
            pst.setString(2, JOGO.getTIMEBJOGO());
            pst.setString(3, JOGO.getGOLSAJOGO());
            pst.setFloat(4, JOGO.getGOLSBJOGO());
            
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
        } catch (SQLException ex) {
            Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
        }
        
        return retorno;
    }
    
    public Boolean excluir(JOGOModelo JOGO)
    {
        String sql = "DELETE FROM TIMEA where id= ?";
        Boolean retorno = false;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
          
            pst.setInt(1, JOGO.getIdJOGO());
            if(pst.executeUpdate()>0)
            {
                retorno = true;
            }
                
         } catch (SQLException ex) {
            Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            retorno = false;
        }
        return retorno;
    }
    
    public List<JOGOModelo> listar()
    {
        String sql = "SELECT * FROM JOGO";
        List<JOGOModelo> lista = new ArrayList<JOGOModelo>();
        JOGOModelo TIMEA = null;
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            ResultSet res = pst.executeQuery();
            while(res.next()){
            
                TIMEA = new JOGOModelo();
                TIMEA.setIdJOGO(res.getInt("id"));
                TIMEA.setTIMEAJOGO(res.getString("TIMEA"));
                TIMEA.setTIMEBJOGO(res.getString("TIMEB"));
                TIMEA.setGOLSAJOGO(res.getString("GOLSA"));
                TIMEA.setGOLSBJOGO(res.getFloat("GOLSB"));
                lista.add(TIMEA);
            }
               
        } catch (SQLException ex) {
            Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
            TIMEA = new JOGOModelo();
            TIMEA.setTIMEAJOGO(ex.getMessage().toString());
            lista.add(TIMEA);
        }
        
        return lista;
        
    }
    
    public JOGOModelo buscar(JOGOModelo JOGO)
    {
        String sql = "SELECT * FROM JOGO where ID=?";
        JOGOModelo retorno = new JOGOModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, JOGO.getTIMEAJOGO());
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new JOGOModelo();
                retorno.setIdJOGO(res.getInt("id"));
                retorno.setTIMEAJOGO(res.getString("TIMEA"));
                retorno.setTIMEBJOGO(res.getString("TIMEB"));
                retorno.setGOLSAJOGO(res.getString("GOLSA"));
                retorno.setGOLSBJOGO(res.getFloat("GOLSB"));
                retorno.setSiglaJOGO(res.getString("sigla"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*JogoDAO TIMEA = new JogoDAO();
        JOGOModelo modelo = new JOGOModelo();
        modelo.setTIMEAJOGO(nmJOGO);
        TIMEA.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
    
    public JOGOModelo buscarPorSigla(JOGOModelo JOGO)
    {
        String sql = "select * from JOGO where sigla like ?";
        JOGOModelo retorno = new JOGOModelo();
        
        PreparedStatement pst = Conexao.getPreparedStatement(sql);
        try {
           
            pst.setString(1, "%" + JOGO.getSiglaJOGO() + "%");
            ResultSet res = pst.executeQuery();
            
            if(res.next())
            {
                retorno = new JOGOModelo();
                retorno.setIdJOGO(res.getInt("id"));
                retorno.setTIMEAJOGO(res.getString("TIMEA"));
                retorno.setTIMEBJOGO(res.getString("TIMEB"));
                retorno.setGOLSAJOGO(res.getString("GOLSA"));
                retorno.setGOLSBJOGO(res.getFloat("GOLSB"));
                retorno.setSiglaJOGO(res.getString("sigla"));
            }
               
        } catch (SQLException ex) {
           Logger.getLogger(dao.JogoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*JogoDAO TIMEA = new JogoDAO();
        JOGOModelo modelo = new JOGOModelo();
        modelo.setTIMEAJOGO(nmJOGO);
        TIMEA.buscar(modelo);
        Gson g = new Gson();*/
        return retorno;
    }
}

